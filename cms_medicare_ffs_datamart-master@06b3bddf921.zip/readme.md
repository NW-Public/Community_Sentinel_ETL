![alt text](https://dev.sentinelsystem.org/projects/AP/repos/sentinel-analytic-packages/raw/resources/logo.png?at=refs%2Fheads%2Fmaster)

<br>

### Welcome to Sentinel's CMS Medicare Fee-For-Service SAS Software Package  

Sentinel has made available the ability to create a Sentinel Common Data Model (SCDM)-formatted dataset using CMS Medicare Fee-For-Service (FFS) source files.  

In order to use the CMS Medicare FFS SAS® Software Package, Sentinel has provided users with the following:  
&nbsp; &nbsp; 1. [<b>Transformation specifications:</b>](Medicare_Fee-For-Service_Data_Transformation_SCDM_Technical_Specifications.pdf) Narrative on the source files and logic rules for transforming the source into the SCDM-formatted database.  
&nbsp; &nbsp; 2. [<b>SAS Code Pack:</b>](CMS-ETL-100pct) Source code for performing the transformation, following the transformation specifications.  
&nbsp; &nbsp; 3. [<b>User Guide:</b>](https://www.sentinelinitiative.org/sentinel/surveillance-tools/software-packages-and-toolkits/centers-medicare-and-medicaid-services-cms-medicare) Helpful information on how to open the SAS Code Pack and set up parameters for use with the source files.  

#### To download contents of this repository:
*  Click the "..." button
*  Select "Download" from the menu that appears  

![screenshot of download](resources/figure1.png)  

<br>  

Additional information can be found on the [<b>Sentinel Initiative website.](https://www.sentinelinitiative.org/sentinel/surveillance-tools/software-packages-and-toolkits/centers-medicare-and-medicaid-services-cms-medicare)  
